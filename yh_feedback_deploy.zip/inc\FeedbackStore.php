<?php
/**
 * 反馈数据存储类（基于 JSON 文件）
 * 提供反馈的增删改查，以及编号生成
 */

class FeedbackStore
{
    /** @var string 数据文件路径 */
    private $file;

    /** @var array 反馈数据（内存缓存） */
    private $data;

    public function __construct($dataDir)
    {
        if (!is_dir($dataDir)) {
            mkdir($dataDir, 0755, true);
        }
        $this->file = rtrim($dataDir, '/\\') . '/feedbacks.json';
        $this->data = $this->load();
    }

    /**
     * 从文件加载数据
     */
    private function load()
    {
        if (!file_exists($this->file)) {
            file_put_contents($this->file, '[]', LOCK_EX);
            return [];
        }
        $raw = file_get_contents($this->file);
        $arr = json_decode($raw, true);
        return is_array($arr) ? $arr : [];
    }

    /**
     * 将数据持久化到文件
     */
    private function save()
    {
        // 加锁写入，避免并发覆盖
        $json = json_encode($this->data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
        file_put_contents($this->file, $json, LOCK_EX);
    }

    /**
     * 生成反馈编号
     * 格式：#FB-年份月份-本月序号，如 #FB-202610-0001
     *
     * @param int $timestamp 提交时间戳
     * @return string 完整编号（不含 # 前缀）
     */
    public function generateId($timestamp = null)
    {
        $ts = $timestamp ?: time();
        $ym = date('Ym', $ts); // 202610
        $seq = 1;
        foreach ($this->data as $item) {
            if (isset($item['no']) && strpos($item['no'], $ym) === 0) {
                // no 形如 "202610-0001"，序号在 "-" 之后
                $parts = explode('-', $item['no']);
                $current = isset($parts[1]) ? (int)$parts[1] : 0;
                $seq = max($seq, $current + 1);
            }
        }
        return sprintf('%s-%04d', $ym, $seq);
    }

    /**
     * 新增一条反馈
     *
     * @param array $feedback 反馈字段（content、senderNickname、senderId、senderType、chatType、type、priority 等）
     * @return array 保存后的完整反馈记录
     */
    public function add(array $feedback)
    {
        $now = time();
        $no = $this->generateId($now);

        $record = [
            'no'          => $no,                       // 如 202610-0001
            'content'     => isset($feedback['content']) ? trim($feedback['content']) : '',
            'status'      => 'pending',                 // pending=待跟进, processing=处理中, resolved=已解决
            'type'        => isset($feedback['type']) ? $feedback['type'] : 'other', // bug=缺陷, suggest=建议, other=其他
            'priority'    => isset($feedback['priority']) ? $feedback['priority'] : 'normal', // high=高, normal=普通, low=低
            'senderNickname' => isset($feedback['senderNickname']) ? $feedback['senderNickname'] : '',
            'senderId'    => isset($feedback['senderId']) ? $feedback['senderId'] : '',
            'senderType'  => isset($feedback['senderType']) ? $feedback['senderType'] : 'user',
            'chatType'    => isset($feedback['chatType']) ? $feedback['chatType'] : 'bot', // bot=私聊, group=群聊
            'chatId'      => isset($feedback['chatId']) ? $feedback['chatId'] : '',
            'likes'       => 0,
            'created_at'  => $now,
            'updated_at'  => $now,
        ];

        $this->data[] = $record;
        $this->save();
        return $record;
    }

    /**
     * 根据编号查找反馈（编号可带 # 前缀或纯编号）
     */
    public function find($no)
    {
        $no = ltrim($no, '#');
        foreach ($this->data as $item) {
            if ($item['no'] === $no) {
                return $item;
            }
        }
        return null;
    }

    /**
     * 获取全部反馈（按创建时间倒序）
     */
    public function all()
    {
        $data = $this->data;
        usort($data, function ($a, $b) {
            return $b['created_at'] <=> $a['created_at'];
        });
        return $data;
    }

    /**
     * 更新反馈（部分字段）
     */
    public function update($no, array $fields)
    {
        $no = ltrim($no, '#');
        foreach ($this->data as &$item) {
            if ($item['no'] === $no) {
                foreach ($fields as $k => $v) {
                    $item[$k] = $v;
                }
                $item['updated_at'] = time();
                $this->save();
                return $item;
            }
        }
        return null;
    }

    /**
     * 删除反馈
     */
    public function delete($no)
    {
        $no = ltrim($no, '#');
        foreach ($this->data as $i => $item) {
            if ($item['no'] === $no) {
                array_splice($this->data, $i, 1);
                $this->save();
                return true;
            }
        }
        return false;
    }

    /**
     * 点赞（like 增加 1）
     */
    public function like($no)
    {
        $item = $this->find($no);
        if ($item) {
            return $this->update($no, ['likes' => $item['likes'] + 1]);
        }
        return null;
    }

    /**
     * 统计数量
     */
    public function count()
    {
        return count($this->data);
    }
}
