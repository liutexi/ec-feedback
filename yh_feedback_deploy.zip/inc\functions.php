<?php
/**
 * 公共辅助函数
 */

/**
 * 获取反馈状态中文名
 */
function status_label($status)
{
    $map = [
        'pending'    => '待跟进',
        'processing' => '处理中',
        'resolved'   => '已解决',
    ];
    return isset($map[$status]) ? $map[$status] : $status;
}

/**
 * 获取反馈类型中文名
 */
function type_label($type)
{
    $map = [
        'bug'     => '缺陷',
        'suggest' => '建议',
        'other'   => '其他',
    ];
    return isset($map[$type]) ? $map[$type] : $type;
}

/**
 * 获取优先级中文名
 */
function priority_label($priority)
{
    $map = [
        'high'   => '高',
        'normal' => '普通',
        'low'    => '低',
    ];
    return isset($map[$priority]) ? $map[$priority] : $priority;
}

/**
 * 格式化时间（YYYY-MM-DD HH:MM）
 */
function fmt_time($ts)
{
    return date('Y-m-d H:i', (int)$ts);
}

/**
 * 完整反馈编号（带 # 前缀），如 #FB-202610-0001
 */
function full_no($no)
{
    return '#FB-' . ltrim($no, '#');
}

/**
 * HTML 转义
 */
function e($str)
{
    return htmlspecialchars((string)$str, ENT_QUOTES, 'UTF-8');
}

/**
 * 从指令消息文本中提取反馈内容
 * 指令消息 content.text 形如 "/反馈 反馈内容" 或 "反馈 反馈内容" 或 "/反馈"
 * 返回去除触发词部分后的内容；若只有触发词本身则返回空字符串
 */
function extract_feedback_content($rawText, $trigger)
{
    $text = trim((string)$rawText);
    $trigger = trim((string)$trigger);
    $trigger = ltrim($trigger, '/#'); // 去掉触发词自带的斜杠，统一匹配

    if ($trigger === '') {
        return $text;
    }

    // 匹配 "/反馈"、"反馈"、"#反馈" 等前缀（可带斜杠）
    $pattern = '#^/?\s*' . preg_quote($trigger, '#') . '(?:\s+|$)#u';
    if (preg_match($pattern, $text)) {
        $rest = preg_replace($pattern, '', $text, 1);
        return trim($rest);
    }

    // 若整条消息就是触发词本身
    if ($text === $trigger || $text === '/' . $trigger || $text === '#' . $trigger) {
        return '';
    }

    // 兜底：直接返回整条（去掉可能的斜杠）
    return trim(ltrim($text, '/#'));
}
